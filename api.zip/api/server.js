// server.js

const express = require('express');
const mongoose = require('mongoose');

const Bot = require('./models/Bot.js');
const Transcript = require('./models/Transcript.js');
const cors = require('cors');
require('dotenv').config();
const app = express();
app.use(express.json());
app.use(cors());
const { generateFromMessages } = require('discord-html-transcripts');

mongoose.connect(process.env.MONGO_URI)
  .then(() => console.log('MongoDB connected'))
  .catch(err => console.error(err));
class MockUser {
  constructor(data) {
    this.id = data.id;
    this.tag = data.tag;
    this.username = data.username || data.tag.split('#')[0];
    this.discriminator = data.discriminator || data.tag.split('#')[1];
    this.bot = data.bot || false;
  }
  displayAvatarURL() {
    // Returner URL til avatar, evt fallback
    return this.avatarURL || 'https://cdn.discordapp.com/embed/avatars/0.png';
  }
}

class MockMessage {
  constructor(data) {
    this.id = data.id;
    this.author = new MockUser(data.author);
    this.createdAt = new Date(data.timestamp);
    this.content = data.content;
    this.attachments = new Map((data.attachments || []).map((att, i) => [i.toString(), att]));
    this.embeds = data.embeds || [];
    this.stickers = data.stickers || [];
    this.components = data.components || [];
    this.reference = null; // eventuelt legge til referanse til annen melding hvis du vil
  }
}
class MockGuild {
  constructor(name) {
    this.name = name;
    this.iconURL = () => null; // evt. legg til URL
    this.roles = {
      everyone: {
        id: '000000000000000000',
        name: '@everyone',
      }
    };
  }
}

class MockChannel {
  constructor(data) {
    this.id = data.id;
    this.name = data.name || 'ticket-channel';
    this.guild = new MockGuild(data.guildName || 'Guild Name');
    this.isDMBased = () => false;
  }
}

app.get('/api/bots', async (req, res) => {
  const bots = await Bot.find({});
  
  res.json({ bots });
});

const { TextChannel } = require('discord.js');

app.get('/transcripts', async (req, res) => {
  const { file } = req.query;
  if (!file) return res.status(400).send('Transcript ID missing.');

  const transcript = await Transcript.findOne({ transcriptId: file });
  if (!transcript) return res.status(404).send('Transcript not found.');

  // Konverter DB-meldinger til MockMessage
  const messages = transcript.messages.map((m, i) => new MockMessage({
    id: m.id.toString(),
    author: {
      id: m.authorId,
      tag: m.authorTag,
      avatarURL: m.authorAvatarURL,
    },
    timestamp: m.timestamp,
    content: m.content,
    attachments: m.attachments || [],
    embeds: m.embeds || [],
  }));

  // Lag mock channel-objekt
  const channel = new MockChannel({
    id: transcript.channelId,
    name: `ticket-${transcript.ticketId}`,
    guildName: transcript.guildName || 'Guild Name'
  });

  try {
    const html = await generateFromMessages(messages, channel, {
      returnType: 'string',
      poweredBy: false,
    });
    res.setHeader('Content-Type', 'text/html');
    res.send(html);
  } catch (err) {
    console.error(err);
    res.status(500).send('Error generating transcript');
  }
});

app.post('/api/bots', async (req, res) => {
  const { clientId, name, avatar, guildCount, latency, users, invite } = req.body;

  const b2 = await Bot.findOne({
    clientId: clientId
  });

  await b2.updateOne({
    clientId: clientId,
    name: name,
    avatar: avatar,
    guildCount: guildCount,
    latency: latency,
    users: users,
    invite: invite,
    lastUpdated: new Date()
  })
  console.log("b2 updated")
  return res.status(200).json({ message: 'Updated' });
});
app.post('/api/bots/register', async (req, res) => {
  const { clientId, name, avatar, guildCount, latency, users, invite } = req.body;

  const b1 = await Bot.findOne({clientId: clientId});

  if(b1) {
    console.log("b1 exists")
    b1.updateOne({
      clientId: clientId,
      name: name, 
      avatar: avatar,
      guildCount: guildCount,
      users: users,
      invite: invite,
      latency: latency,
      lastUpdated: new Date()
    })
    console.log('Bot exists and Updated');
    return res.status(200).json({ message: 'Bot exists and Updated' });
  }
console.log("b1 created, not exists")
  await Bot.create({
    clientId: clientId,
    name: name,
    avatar: avatar,
    guildCount: guildCount,
    latency: latency,
    users: users,
    invite: invite,
    lastUpdated: new Date()
  })
  console.log('Bot created and Updated');

  return res.status(200).json({ message: 'Bot created' });
});

app.listen(process.env.PORT, () => {
  console.log(`API running on http://localhost:${process.env.PORT}`);
});
