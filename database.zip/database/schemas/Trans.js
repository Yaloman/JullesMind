const mongoose = require('mongoose');

const attachmentSchema = new mongoose.Schema({
  id: String,
  url: String,
  proxyURL: String,
  name: String,
  contentType: String,
  size: Number,
});

const embedSchema = new mongoose.Schema({
  title: String,
  description: String,
  url: String,
  color: Number,
  footer: {
    text: String,
    iconURL: String,
  },
  image: {
    url: String,
  },
  thumbnail: {
    url: String,
  },
  author: {
    name: String,
    url: String,
    iconURL: String,
  },
  fields: [{
    name: String,
    value: String,
    inline: Boolean,
  }],
});

const messageSchema = new mongoose.Schema({
  _id: false,
  id: { type: String, required: true }, // message id
  authorId: { type: String, required: true },
  authorTag: { type: String, required: true },
  authorAvatarURL: { type: String, default: null },
  content: { type: String, default: '' },
  timestamp: { type: Date, required: true },
  attachments: { type: [attachmentSchema], default: [] },
  embeds: { type: [embedSchema], default: [] },
  // legg til flere felt ved behov
});

const transcriptSchema = new mongoose.Schema({
  transcriptId: { type: String, unique: true, required: true },
  ticketId: { type: String, required: true },
  userId: { type: String, required: true },
  channelId: { type: String, required: true },
  guildName: { type: String, default: '' },
  messages: { type: [messageSchema], default: [] },
  createdAt: { type: Date, default: Date.now },
});

module.exports = mongoose.model('Transcript', transcriptSchema);
